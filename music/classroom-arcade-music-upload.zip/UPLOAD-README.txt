CLASSROOM ARCADE MUSIC UPLOAD PACKAGE

Contents:
- audio/ : 11 MP3 files, renamed to stable URL-friendly filenames
- tracks.json : playlist entries pointing at ./audio/...

To publish on GitHub Pages:
1. Open your classroom-arcade GitHub repository.
2. Open the music/ folder.
3. Upload the audio folder's 11 MP3 files into music/audio/ (create audio/ if needed).
4. Replace music/tracks.json with this package's tracks.json.
5. Wait for GitHub Pages to redeploy, then reload the Arcade Music page.

Important: this ZIP is a prepared upload package; it has not itself been uploaded to GitHub.
